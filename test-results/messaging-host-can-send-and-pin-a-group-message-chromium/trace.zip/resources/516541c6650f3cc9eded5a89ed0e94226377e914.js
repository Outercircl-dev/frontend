(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_c9e16793._.js",
  "static/chunks/d6fbb_next_dist_compiled_react-dom_aa291123._.js",
  "static/chunks/d6fbb_next_dist_compiled_react-server-dom-turbopack_5f9557f0._.js",
  "static/chunks/d6fbb_next_dist_compiled_next-devtools_index_10ee4c6f.js",
  "static/chunks/d6fbb_next_dist_compiled_65d35555._.js",
  "static/chunks/d6fbb_next_dist_client_9b6988f5._.js",
  "static/chunks/d6fbb_next_dist_1e5c7dfc._.js",
  "static/chunks/69652_@swc_helpers_cjs_679851cc._.js"
],
    source: "entry"
});
