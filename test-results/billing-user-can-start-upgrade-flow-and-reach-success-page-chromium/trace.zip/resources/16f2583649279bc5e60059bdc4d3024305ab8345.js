(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules__pnpm_c25e083f._.js",
  "static/chunks/_b54982b3._.js"
],
    source: "dynamic"
});
